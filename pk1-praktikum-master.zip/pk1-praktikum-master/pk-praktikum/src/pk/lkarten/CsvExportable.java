package pk.lkarten;

public interface CsvExportable {

	public abstract String exportiereAlsCsv();
}